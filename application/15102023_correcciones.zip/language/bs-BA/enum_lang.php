<?php
$lang["enum_half_down"] = "Pola dolje";
$lang["enum_half_even"] = "Pola ravnomjerno";
$lang["enum_half_five"] = "Pola na pet";
$lang["enum_half_odd"] = "Pola neparno";
$lang["enum_half_up"] = "Pola gore";
$lang["enum_round_down"] = "Zaokruži naniže";
$lang["enum_round_up"] = "Zaokruži naviše";
