<?php 

$lang["category_name_required"] = "اسم نوع المصاريف مطلوب";
$lang["expenses_categories_add_item"] = "إضافة نوع";
$lang["expenses_categories_cannot_be_deleted"] = "فشلت عملية مسح نوع المصاريف";
$lang["expenses_categories_category_id"] = "الكود";
$lang["expenses_categories_confirm_delete"] = "هل أنت متأكد من مسح نوع المصاريف الذي أخترته؟";
$lang["expenses_categories_confirm_restore"] = "هل أنت متأكد من أنك تريد استعادة فئة المصاريف المحددة؟";
$lang["expenses_categories_description"] = "وصف النوع";
$lang["expenses_categories_error_adding_updating"] = "مشكلة أثناء أضافة أو تعديل نوع المصاريف";
$lang["expenses_categories_info"] = "معلومات عن نوع المصاريف";
$lang["expenses_categories_name"] = "أسم النوع";
$lang["expenses_categories_new"] = "نوع جديد";
$lang["expenses_categories_no_expenses_categories_to_display"] = "لا يجد أنواع للعرض";
$lang["expenses_categories_none_selected"] = "لم تختار أي نوع مصاريف";
$lang["expenses_categories_one_or_multiple"] = "نوع المصاريف";
$lang["expenses_categories_quantity"] = "الكمية";
$lang["expenses_categories_successful_adding"] = "تم أضافة نوع المصاريف بنجاح";
$lang["expenses_categories_successful_deleted"] = "تم مسح نوع المصاريف بنجاح";
$lang["expenses_categories_successful_updating"] = "تم تعديل نوع المصاريف بنجاح";
$lang["expenses_categories_update"] = "تعديل النوع";
