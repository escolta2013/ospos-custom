<?php 

$lang["tables_all"] = "همه";
$lang["tables_columns"] = "ستون ها";
$lang["tables_hide_show_pagination"] = "پنهان کردن / نمایش صفحه بندی";
$lang["tables_loading"] = "...در حال بارگزاری، لطفا منتظر بمانید";
$lang["tables_page_from_to"] = "نمایش {0} تا {1} از {2} ردیف";
$lang["tables_refresh"] = "تازه کردن";
$lang["tables_rows_per_page"] = "صفر ردیف در هر صفحه";
$lang["tables_toggle"] = "تغییر وضعیت";
