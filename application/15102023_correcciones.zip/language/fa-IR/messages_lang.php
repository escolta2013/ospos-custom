<?php 

$lang["messages_first_name"] = "نام کوچک";
$lang["messages_last_name"] = "نام خانوادگی";
$lang["messages_message"] = "پیام";
$lang["messages_message_placeholder"] = "پیام شما در اینجا ...";
$lang["messages_message_required"] = "پیام لازم است";
$lang["messages_multiple_phones"] = "(در صورت دریافت کننده های متعدد ، شماره های تلفن همراه را که با کاما از هم جدا شده اند وارد کنید)";
$lang["messages_phone"] = "شماره تلفن";
$lang["messages_phone_number_required"] = "شماره تلفن مورد نیاز است";
$lang["messages_phone_placeholder"] = "شماره تلفن همراه (ها) در اینجا ...";
$lang["messages_sms_send"] = "ارسال پیامک";
$lang["messages_successfully_sent"] = "پیام با موفقیت ارسال شد به:";
$lang["messages_unsuccessfully_sent"] = "پیغام با موفقیت ارسال شد:";
