<?php 

$lang["login_gcaptcha"] = "من روبات نیستم.";
$lang["login_go"] = "برو";
$lang["login_invalid_gcaptcha"] = "نامعتبر من یک روبات نیستم.";
$lang["login_invalid_installation"] = "نصب صحیح نیست ، پرونده php.ini خود را بررسی کنید.";
$lang["login_invalid_username_and_password"] = "نام کاربری یا گذرواژه نامعتبر است.";
$lang["login_login"] = "وارد شدن";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "کلمه عبور";
$lang["login_username"] = "نام کاربری";
$lang["login_welcome"] = "";
