<?php 

$lang["enum_half_down"] = "";
$lang["enum_half_even"] = "";
$lang["enum_half_five"] = "";
$lang["enum_half_odd"] = "";
$lang["enum_half_up"] = "";
$lang["enum_round_down"] = "";
$lang["enum_round_up"] = "";
