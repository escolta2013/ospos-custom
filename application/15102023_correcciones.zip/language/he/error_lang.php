<?php 

$lang["error_no_permission_module"] = "אין לך הרשאה לגשת אל המודול ששמו";
$lang["error_unknown"] = "שגיאה לא ידועה";
