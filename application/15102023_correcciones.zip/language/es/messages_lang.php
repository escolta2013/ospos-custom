<?php 

$lang["messages_first_name"] = "Nombre";
$lang["messages_last_name"] = "Apellidos";
$lang["messages_message"] = "Mensaje";
$lang["messages_message_placeholder"] = "Su mensaje aquí…";
$lang["messages_message_required"] = "Mensaje es requerido";
$lang["messages_multiple_phones"] = "(En Caso de varios destinatarios, ingresar los numeros de telefono separados por comas)";
$lang["messages_phone"] = "Numero de Telefono";
$lang["messages_phone_number_required"] = "El Telefono es requerido";
$lang["messages_phone_placeholder"] = "Numero de Celular aquí…";
$lang["messages_sms_send"] = "Enviar SMS";
$lang["messages_successfully_sent"] = "Mensaje exitosamente enviado a: ";
$lang["messages_unsuccessfully_sent"] = "Mensaje no pudo ser enviado a: ";
