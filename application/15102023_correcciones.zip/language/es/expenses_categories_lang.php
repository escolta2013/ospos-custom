<?php 

$lang["category_name_required"] = "nombre requerido-";
$lang["expenses_categories_add_item"] = "Agregar categoria";
$lang["expenses_categories_cannot_be_deleted"] = "No pudo borrar";
$lang["expenses_categories_category_id"] = "Id";
$lang["expenses_categories_confirm_delete"] = "Esta seguro de quere borrar lo(s) categorias(s) seleccionado(s)?";
$lang["expenses_categories_confirm_restore"] = "¿Está seguro de que desea restaurar la categoría de gastos seleccionada?";
$lang["expenses_categories_description"] = "Descripcion Categoria";
$lang["expenses_categories_error_adding_updating"] = "Error actualizando/adicinando categoria";
$lang["expenses_categories_info"] = "Informacion Categoria";
$lang["expenses_categories_name"] = "Nombre Categoria";
$lang["expenses_categories_new"] = "Nueva Categoria";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Ninguna categoria para mostrar";
$lang["expenses_categories_none_selected"] = "No ha seleccionado nada";
$lang["expenses_categories_one_or_multiple"] = "Categoria de gasto";
$lang["expenses_categories_quantity"] = "Oferta";
$lang["expenses_categories_successful_adding"] = "Categoria adicionada";
$lang["expenses_categories_successful_deleted"] = "Categoria borrada";
$lang["expenses_categories_successful_updating"] = "Categoria actualizada";
$lang["expenses_categories_update"] = "Actualizar Categoria";
