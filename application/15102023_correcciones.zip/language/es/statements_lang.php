<?php 
$lang["statements_dell"] = "Permitir Borrar Abonos";
$lang["statements_receipt"] = "Imprimir Recibo";
$lang["statements_recibo"] = "Recv N°";  
$lang["statements_paymentamount"] = "Recibido"; 
$lang["statements_paymentamount_t"] = "Total Pagos";
$lang["statements_deuda"] = "Deudado";   
$lang["statements_payment_time"] = "Fecha Pago"; 
$lang["statements_impinvoice"] = "Imprimir Factura";
$lang["statements_pay"] = "Pagar";
$lang["statements_dell"] = "Borrar";
$lang["statements_add_amount"] = "Agregar Monto";
