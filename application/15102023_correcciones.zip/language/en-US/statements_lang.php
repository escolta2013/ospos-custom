<?php 
$lang["statements_recibo"] = "Receipt No.";
$lang["statements_paymentamount"] = "Received Payment";
$lang["statements_paymentamount_t"] = "Total Payments";
$lang["statements_deuda"] = "Amount Owed";
$lang["statements_payment_time"] = "Payment Date";
$lang["statements_impinvoice"] = "Print. Invoice";
$lang["statements_pay"] = "Pay";
$lang["statements_dell"] = "Dell";
$lang["statements_add_amount"] = "Add Amount";


