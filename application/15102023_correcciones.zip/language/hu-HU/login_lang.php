<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "Juhúúúúúú!";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "Érvénytelen felhasználói név vagy jelszó";
$lang["login_login"] = "Belépés";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "Jelszó";
$lang["login_username"] = "Felhasználó név";
$lang["login_welcome"] = "";
