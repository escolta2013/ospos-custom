<?php 

$lang["error_no_permission_module"] = "Você não tem permissão para acessar o módulo chamado";
$lang["error_unknown"] = "Desconhecido";
