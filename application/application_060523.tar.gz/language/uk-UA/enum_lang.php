<?php 

$lang["enum_half_down"] = "Половина вниз";
$lang["enum_half_even"] = "Половина";
$lang["enum_half_five"] = "Половина п'яти";
$lang["enum_half_odd"] = "Половина непарного";
$lang["enum_half_up"] = "Половина вгору";
$lang["enum_round_down"] = "Заокруглити";
$lang["enum_round_up"] = "Об'єднати";
