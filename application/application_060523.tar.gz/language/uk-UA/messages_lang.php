<?php 

$lang["messages_first_name"] = "Ім'я";
$lang["messages_last_name"] = "Прізвище";
$lang["messages_message"] = "Повідомлення";
$lang["messages_message_placeholder"] = "Напишіть тут ваше повідомленя.";
$lang["messages_message_required"] = "Заповніть текст повідомлення";
$lang["messages_multiple_phones"] = "(Якщо декілька одержувачів, введіть номери мобільних телефонів, розділені комами)";
$lang["messages_phone"] = "Номер телефону";
$lang["messages_phone_number_required"] = "Необхідний номер телефону";
$lang["messages_phone_placeholder"] = "Мобільний номер (и) тут ...";
$lang["messages_sms_send"] = "Надіслати SMS";
$lang["messages_successfully_sent"] = "Повідомлення успішно надіслано: ";
$lang["messages_unsuccessfully_sent"] = "Повідомлення невдало надіслано: ";
