<?php 

$lang["tables_all"] = "Toate";
$lang["tables_columns"] = "Coloane";
$lang["tables_hide_show_pagination"] = "Ascunde/Arată paginare";
$lang["tables_loading"] = "Se încarcă, vă rugăm așteptați...";
$lang["tables_page_from_to"] = "Arată {0} până la {1} din {2} rânduri";
$lang["tables_refresh"] = "Reîmprospătare";
$lang["tables_rows_per_page"] = "{0} rânduri per pagină";
$lang["tables_toggle"] = "Comută";
