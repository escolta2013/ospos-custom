<?php 

$lang["error_no_permission_module"] = "Nu aveti permisiunea de acces a modulului numit";
$lang["error_unknown"] = "Eroare neasteptata";
