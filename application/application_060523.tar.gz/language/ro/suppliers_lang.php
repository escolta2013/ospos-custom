<?php 

$lang["suppliers_account_number"] = "Număr cont";
$lang["suppliers_agency_name"] = "Nume Agenție";
$lang["suppliers_cannot_be_deleted"] = "Nu pot șterge Funrizorul/Furnizorii selectat/selectați. Unul sau mai mulți au Vânzări.";
$lang["suppliers_category"] = "Categorie";
$lang["suppliers_company_name"] = "Nume Companie";
$lang["suppliers_company_name_required"] = "Este obligatoriu câmpul Nume Companie.";
$lang["suppliers_confirm_delete"] = "";
$lang["suppliers_confirm_restore"] = "";
$lang["suppliers_cost"] = "";
$lang["suppliers_error_adding_updating"] = "";
$lang["suppliers_goods"] = "";
$lang["suppliers_new"] = "";
$lang["suppliers_none_selected"] = "";
$lang["suppliers_one_or_multiple"] = "";
$lang["suppliers_successful_adding"] = "";
$lang["suppliers_successful_deleted"] = "";
$lang["suppliers_successful_updating"] = "";
$lang["suppliers_supplier"] = "";
$lang["suppliers_supplier_id"] = "";
$lang["suppliers_tax_id"] = "";
$lang["suppliers_update"] = "";
