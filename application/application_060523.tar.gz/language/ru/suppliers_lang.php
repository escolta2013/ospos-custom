<?php 

$lang["suppliers_account_number"] = "Номер Счета";
$lang["suppliers_agency_name"] = " ";
$lang["suppliers_cannot_be_deleted"] = "Не удалось удалить выбранные поставщиков, один или более из выбранных поставщиков имеет продаж.";
$lang["suppliers_category"] = "";
$lang["suppliers_company_name"] = "Название компании";
$lang["suppliers_company_name_required"] = "Название Компании - обязательное поле для заполнения.";
$lang["suppliers_confirm_delete"] = "Вы уверены, что хотите удалить выбранных поставщиков?";
$lang["suppliers_confirm_restore"] = "Вы уверены, что хотите восстановить выбранных поставщиков?";
$lang["suppliers_cost"] = "";
$lang["suppliers_error_adding_updating"] = "Ошибка при добавлении/обновлении поставщиком.";
$lang["suppliers_goods"] = "";
$lang["suppliers_new"] = "Новый поставщик";
$lang["suppliers_none_selected"] = "Вы не выбрали ни поставщики удалить.";
$lang["suppliers_one_or_multiple"] = "поставщик (а)";
$lang["suppliers_successful_adding"] = "Вы успешно добавили поставщиком";
$lang["suppliers_successful_deleted"] = "Вы успешно удален";
$lang["suppliers_successful_updating"] = "Вы успешно обновляли поставщиком";
$lang["suppliers_supplier"] = "поставщик";
$lang["suppliers_supplier_id"] = "Ид";
$lang["suppliers_tax_id"] = "";
$lang["suppliers_update"] = "Обновить поставщика";
