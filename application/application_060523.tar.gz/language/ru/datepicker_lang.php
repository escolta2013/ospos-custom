<?php 

$lang["datepicker_all_time"] = "за все время";
$lang["datepicker_apply"] = "";
$lang["datepicker_cancel"] = "";
$lang["datepicker_custom"] = "";
$lang["datepicker_from"] = "";
$lang["datepicker_last_30"] = "Последние 30 дней";
$lang["datepicker_last_7"] = "Последние 7 дней";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Последний месяц";
$lang["datepicker_last_year"] = "в прошлом году";
$lang["datepicker_same_month_last_year"] = "";
$lang["datepicker_same_month_to_same_day_last_year"] = "";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "В этом месяце";
$lang["datepicker_this_year"] = "В этом году";
$lang["datepicker_to"] = "";
$lang["datepicker_today"] = "сегодня";
$lang["datepicker_today_last_year"] = "";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "вчера";
