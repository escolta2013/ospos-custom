<?php
$lang["messages_first_name"] = "";
$lang["messages_last_name"] = "";
$lang["messages_message"] = "Сообщение";
$lang["messages_message_placeholder"] = "";
$lang["messages_message_required"] = "";
$lang["messages_multiple_phones"] = "";
$lang["messages_phone"] = "Номер телефона";
$lang["messages_phone_number_required"] = "";
$lang["messages_phone_placeholder"] = "";
$lang["messages_sms_send"] = "Отправить SMS";
$lang["messages_successfully_sent"] = "";
$lang["messages_unsuccessfully_sent"] = "";
