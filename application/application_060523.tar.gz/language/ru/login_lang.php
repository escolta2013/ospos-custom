<?php 

$lang["login_gcaptcha"] = "Я не робот.";
$lang["login_go"] = "ходите";
$lang["login_invalid_gcaptcha"] = "Неверный Логин";
$lang["login_invalid_installation"] = "Настройки неверные, проверьте php.ini";
$lang["login_invalid_username_and_password"] = "Неправильное Имя или Пароль";
$lang["login_login"] = "Логин";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "Пароль";
$lang["login_username"] = "Имя пользователя";
$lang["login_welcome"] = "";
