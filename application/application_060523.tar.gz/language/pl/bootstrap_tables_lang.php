<?php
$lang["tables_all"] = "wszystko";
$lang["tables_columns"] = "Kolumny";
$lang["tables_hide_show_pagination"] = "Ukryj/pokaż paginację";
$lang["tables_loading"] = "Ładowanie, proszę czekać...";
$lang["tables_page_from_to"] = "Pokazuję od {0} do {1} z {2} wierszy";
$lang["tables_refresh"] = "Odśwież";
$lang["tables_rows_per_page"] = "{0} wierszy na stronę";
$lang["tables_toggle"] = "Włącz";
