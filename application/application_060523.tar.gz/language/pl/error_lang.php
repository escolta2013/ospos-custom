<?php
$lang["error_no_permission_module"] = "Nie masz dostępu do modułu";
$lang["error_unknown"] = "Niespodziewany błąd";
