<?php 

$lang["error_no_permission_module"] = "U bent niet gemachtigd voor toegang tot de module genaamd";
$lang["error_unknown"] = "Onverwachte fout";
