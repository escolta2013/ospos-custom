<?php 

$lang["category_name_required"] = "Onkostencategorie naam is vereist";
$lang["expenses_categories_add_item"] = "Category toevoegen";
$lang["expenses_categories_cannot_be_deleted"] = "Kan categorie onkosten niet verwijderen";
$lang["expenses_categories_category_id"] = "ID";
$lang["expenses_categories_confirm_delete"] = "Weet u zeker dat u de geselecteerde categorie onkosten wilt verwijderen?";
$lang["expenses_categories_confirm_restore"] = "Weet u zeker dat u de geselecteerde categorie onkosten wilt herstellen?";
$lang["expenses_categories_description"] = "Categorie beschrijving";
$lang["expenses_categories_error_adding_updating"] = "Fout bij toevoegen/bijwerken onkosten categorie";
$lang["expenses_categories_info"] = "Categorie onkosten info";
$lang["expenses_categories_name"] = "Categorie naam";
$lang["expenses_categories_new"] = "Nieuwe categorie";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Geen categorie om te weergeven";
$lang["expenses_categories_none_selected"] = "Geen categorie onkosten geselecteerd";
$lang["expenses_categories_one_or_multiple"] = "Categorie onkosten";
$lang["expenses_categories_quantity"] = "Hoeveelheid";
$lang["expenses_categories_successful_adding"] = "Onkosten categorie toegevoegd";
$lang["expenses_categories_successful_deleted"] = "Onkosten categorie verwijderd";
$lang["expenses_categories_successful_updating"] = "Onkosten categorie bijgewerkt";
$lang["expenses_categories_update"] = "Categorie bijwerken";
