<?php 

$lang["messages_first_name"] = "Nome";
$lang["messages_last_name"] = "Cognome";
$lang["messages_message"] = "Messaggio";
$lang["messages_message_placeholder"] = "Il tuo messaggio qui...";
$lang["messages_message_required"] = "Messaggio richiesto";
$lang["messages_multiple_phones"] = "(In caso di destinatari multipli, inserire il numero separato da virgole)";
$lang["messages_phone"] = "Numero cellulare";
$lang["messages_phone_number_required"] = "Numero cellulare richiesto";
$lang["messages_phone_placeholder"] = "Numero(i) cellulare qui...";
$lang["messages_sms_send"] = "Manda SMS";
$lang["messages_successfully_sent"] = "Hai correttamente inviato a: ";
$lang["messages_unsuccessfully_sent"] = "Messaggio non inviato correttamente a: ";
