<?php
$lang["login_gcaptcha"] = "Non sono un robot.";
$lang["login_go"] = "Go";
$lang["login_invalid_gcaptcha"] = "Verifica di non essere un robot.";
$lang["login_invalid_installation"] = "L'installazione non è corretta, controlla il tuo file php.ini.";
$lang["login_invalid_username_and_password"] = "Username o Password non validi.";
$lang["login_login"] = "Login";
$lang["login_logout"] = "Uscita";
$lang["login_migration_needed"] = "Dopo l'accesso verrà avviata una migrazione del database a %1.";
$lang["login_password"] = "Password";
$lang["login_username"] = "Username";
$lang["login_welcome"] = "Benvenuto in %1!";
