<?php
$lang["login_gcaptcha"] = "Ik ben geen robot.";
$lang["login_go"] = "Verstuur";
$lang["login_invalid_gcaptcha"] = "Controleer of u geen robot bent.";
$lang["login_invalid_installation"] = "De installatie is onvolledig. Kijk uw php.ini file na.";
$lang["login_invalid_username_and_password"] = "Ongeldige gebruiker en/of paswoord.";
$lang["login_login"] = "Login";
$lang["login_logout"] = "Log-uit";
$lang["login_migration_needed"] = "Een database migratie naar %1 zal starten na het inloggen.";
$lang["login_password"] = "Paswoord";
$lang["login_username"] = "Gebruiker";
$lang["login_welcome"] = "Welkom op %1!";
