<?php 

$lang["category_name_required"] = "តំរូវអោយបំពេញឈ្មោះប្រភេទចំណាយ";
$lang["expenses_categories_add_item"] = "បន្ថែមប្រភេទ";
$lang["expenses_categories_cannot_be_deleted"] = "មិនអាចលប់ប្រភេទចំណាយបាន";
$lang["expenses_categories_category_id"] = "លេខសំគាល់";
$lang["expenses_categories_confirm_delete"] = "តើអ្នកពិតជាចង់លប់ប្រភេទចំណាយដែលបានជ្រើរើសមែនទេ?";
$lang["expenses_categories_confirm_restore"] = "";
$lang["expenses_categories_description"] = "ពិពណ៌នាអំពីប្រភេទ";
$lang["expenses_categories_error_adding_updating"] = "កំហុសក្នុងការបន្ថែម / ធ្វើបច្ចុប្បន្នភាពប្រភេទចំណាយ";
$lang["expenses_categories_info"] = "ពត៌មានប្រភេទចំណាយ";
$lang["expenses_categories_name"] = "ឈ្មោះប្រភេទ";
$lang["expenses_categories_new"] = "ប្រភេទថ្មី";
$lang["expenses_categories_no_expenses_categories_to_display"] = "គ្មានប្រភេទសំរាប់បង្ហាញ";
$lang["expenses_categories_none_selected"] = "អ្នកមិនទាន់ជ្រើរើសប្រភេទចំណាយណាមួយនុះឡើយ";
$lang["expenses_categories_one_or_multiple"] = "ប្រភេទចំណាយ";
$lang["expenses_categories_quantity"] = "បរិមាណ";
$lang["expenses_categories_successful_adding"] = "បន្ថែមប្រភេទចំណាយបានជោគជ័យ";
$lang["expenses_categories_successful_deleted"] = "លប់ប្រភេទចំណាយបានជោគជ័យ";
$lang["expenses_categories_successful_updating"] = "ធ្វើបច្ចុប្បន្នភាពប្រភេទចំណាយបានជោគជ័យ";
$lang["expenses_categories_update"] = "ធ្វើបច្ចុប្បន្នភាពប្រភេទ";
