<?php 

$lang["login_gcaptcha"] = "我不是機器人。";
$lang["login_go"] = "登入";
$lang["login_invalid_gcaptcha"] = "請確認您不是機器人。";
$lang["login_invalid_installation"] = "安裝不正確，請檢查您的php.ini文件。";
$lang["login_invalid_username_and_password"] = "帳號或密碼錯誤。";
$lang["login_login"] = "登入";
$lang["login_logout"] = "登出";
$lang["login_migration_needed"] = "登錄後將開始向 %1 的數據庫遷移。";
$lang["login_password"] = "密碼";
$lang["login_username"] = "帳號";
$lang["login_welcome"] = "歡迎來到 %1！";
