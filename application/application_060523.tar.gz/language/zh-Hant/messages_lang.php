<?php 

$lang["messages_first_name"] = "名字";
$lang["messages_last_name"] = "姓氏";
$lang["messages_message"] = "Message";
$lang["messages_message_placeholder"] = "你的訊息.....";
$lang["messages_message_required"] = "訊息必須填寫";
$lang["messages_multiple_phones"] = "（如果是多個收件人，請輸入以逗號分隔的手機號碼）";
$lang["messages_phone"] = "電話號碼";
$lang["messages_phone_number_required"] = "電話號碼是必須";
$lang["messages_phone_placeholder"] = "手機號碼在這裡填寫......";
$lang["messages_sms_send"] = "Send SMS";
$lang["messages_successfully_sent"] = "消息已成功發送至： ";
$lang["messages_unsuccessfully_sent"] = "消息未成功發送至： ";
