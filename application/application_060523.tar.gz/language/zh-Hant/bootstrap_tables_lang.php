<?php 

$lang["tables_all"] = "全部";
$lang["tables_columns"] = "列";
$lang["tables_hide_show_pagination"] = "隱藏/顯示分頁";
$lang["tables_loading"] = "加載數據中，請稍候……";
$lang["tables_page_from_to"] = "顯示第 {0} 至第 {1} 條記錄，總共 {2} 條記錄";
$lang["tables_refresh"] = "重新";
$lang["tables_rows_per_page"] = "每頁顯示 {0} 條記錄";
$lang["tables_toggle"] = "切換";
