<?php 

$lang["category_name_required"] = "Gider Kategorisi adı gerekli";
$lang["expenses_categories_add_item"] = "Kategori ekleyin";
$lang["expenses_categories_cannot_be_deleted"] = "Gider kategorisi silinemez";
$lang["expenses_categories_category_id"] = "No";
$lang["expenses_categories_confirm_delete"] = "Seçili Gider Kategorisini silmek istediğinizden emin misiniz?";
$lang["expenses_categories_confirm_restore"] = "Seçili Gider Kategorisini geri yüklemek istediğinize emin misiniz?";
$lang["expenses_categories_description"] = "Kategori Tanımı";
$lang["expenses_categories_error_adding_updating"] = "Gider Kategorisi ekleme/güncelleme hatası";
$lang["expenses_categories_info"] = "Giderler Kategorisi Bilgisi";
$lang["expenses_categories_name"] = "Kategori Adı";
$lang["expenses_categories_new"] = "Yeni Kategori";
$lang["expenses_categories_no_expenses_categories_to_display"] = "Görüntülenecek Kategori yok";
$lang["expenses_categories_none_selected"] = "Seçili Gider Kategorisi yok";
$lang["expenses_categories_one_or_multiple"] = "Gider Kategorisi";
$lang["expenses_categories_quantity"] = "Sayı";
$lang["expenses_categories_successful_adding"] = "Gider Kategorisi eklendi";
$lang["expenses_categories_successful_deleted"] = "Gider Kategorisi silindi";
$lang["expenses_categories_successful_updating"] = "Gider Kategorisi güncellendi";
$lang["expenses_categories_update"] = "Gider Kategorisini güncelle";
