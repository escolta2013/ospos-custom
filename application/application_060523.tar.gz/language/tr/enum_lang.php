<?php 

$lang["enum_half_down"] = "Yarım Aşağı";
$lang["enum_half_even"] = "Yarım Çift";
$lang["enum_half_five"] = "Beş Buçuk";
$lang["enum_half_odd"] = "Yarım Tek";
$lang["enum_half_up"] = "Yarım Yukarı";
$lang["enum_round_down"] = "Aşağı Yuvarla";
$lang["enum_round_up"] = "Yukarı Yuvarla";
