<?php 

$lang["tables_all"] = "Alle";
$lang["tables_columns"] = "Kolonner";
$lang["tables_hide_show_pagination"] = "Gem/Vis sideinddeling";
$lang["tables_loading"] = "Indlæser, vent venligst...";
$lang["tables_page_from_to"] = "Viser {0} to {1} af {2} rækker";
$lang["tables_refresh"] = "Opdater";
$lang["tables_rows_per_page"] = "{0} rækker per side";
$lang["tables_toggle"] = "Skift";
