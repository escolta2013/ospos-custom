<?php 

$lang["login_gcaptcha"] = "我不是机器人。";
$lang["login_go"] = "登入";
$lang["login_invalid_gcaptcha"] = "无效，我不是机器人。";
$lang["login_invalid_installation"] = "安装不正确，请检查您的php.ini文件。";
$lang["login_invalid_username_and_password"] = "无效的用户名或密码。";
$lang["login_login"] = "登入";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "密码";
$lang["login_username"] = "用户名";
$lang["login_welcome"] = "";
