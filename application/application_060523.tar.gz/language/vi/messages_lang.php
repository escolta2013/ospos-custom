<?php 

$lang["messages_first_name"] = "Tên";
$lang["messages_last_name"] = "Họ";
$lang["messages_message"] = "Tin nhắn";
$lang["messages_message_placeholder"] = "Tin nhắn của bạn ở đây...";
$lang["messages_message_required"] = "Cần tin nhắn";
$lang["messages_multiple_phones"] = "(Trong trường hợp gửi cho nhiều người, nhập danh sách điện thoại ngăn cách nhau bởi dấu phẩy)";
$lang["messages_phone"] = "Số điện thoại";
$lang["messages_phone_number_required"] = "Cần số điện thoại";
$lang["messages_phone_placeholder"] = "Các số di động ở đây...";
$lang["messages_sms_send"] = "Gửi SMS";
$lang["messages_successfully_sent"] = "Tin nhắn được gửi thành công cho: ";
$lang["messages_unsuccessfully_sent"] = "Tin nhắn được gửi không thành công cho: ";
