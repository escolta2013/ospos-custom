<?php 

$lang["tables_all"] = "ทั้งหมด";
$lang["tables_columns"] = "คอลัมน์";
$lang["tables_hide_show_pagination"] = "ซ่อน/แสดง รายการหน้า";
$lang["tables_loading"] = "กำลังดำเนินการ รอสักครู่";
$lang["tables_page_from_to"] = "แสดง {0} ถึง {1} จาก {2} รายการ";
$lang["tables_refresh"] = "Refresh ข้อมูล";
$lang["tables_rows_per_page"] = "{0} รายการ/หน้า";
$lang["tables_toggle"] = "ซ่อน/แสดง";
