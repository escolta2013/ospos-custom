<?php 

$lang["enum_half_down"] = "ครึ่งล่าง";
$lang["enum_half_even"] = "ครึ่งคู่";
$lang["enum_half_five"] = "ครึ่งห้า";
$lang["enum_half_odd"] = "ครึ่งคี่";
$lang["enum_half_up"] = "ครึ่งบน";
$lang["enum_round_down"] = "ปัดเศษลง";
$lang["enum_round_up"] = "ปัดเศษขึน";
