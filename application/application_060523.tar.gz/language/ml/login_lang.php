<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "";
$lang["login_login"] = "";
$lang["login_logout"] = "";
$lang["login_migration_needed"] = "";
$lang["login_password"] = "";
$lang["login_username"] = "";
$lang["login_welcome"] = "";
